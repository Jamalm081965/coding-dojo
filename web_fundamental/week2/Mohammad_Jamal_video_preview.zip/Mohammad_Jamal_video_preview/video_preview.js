var video = document.querySelector(".mainVideo");
function playvideo() {
    if (video) {
        video.play();
    }
}
function pausevideo() {
    if (video) {
        video.pause();
        }
    
}
