var count = 0;
var likebutton1 = document.querySelector(".like-nav1");

function increaselikes1() {
    count++;
    likebutton1.innerText = count + " Like(s)";
}

var count = 0;
var likebutton2= document.querySelector(".like-nav2");
function increaselikes2() {
    count++;
    likebutton2.innerText = count + " Like(s)";
}
var count = 0;
var likebutton3 = document.querySelector(".like-nav3");
function increaselikes3() {
    count++;
    likebutton3.innerText = count + " Like(s)";
}