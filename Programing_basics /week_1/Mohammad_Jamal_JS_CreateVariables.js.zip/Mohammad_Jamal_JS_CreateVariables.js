//This variable is set to check minimum hight requirement, rider has to be 42 inchs tall
var RiderHight = 42;
// add console.log to test my work
//console.log(RiderHight);
// This varible is set to check the minimum age requirement, rider has to be 10 years old or over
var RiderAge = 10 ;
// add console.log to test my work 
//console.log(RiderAge);