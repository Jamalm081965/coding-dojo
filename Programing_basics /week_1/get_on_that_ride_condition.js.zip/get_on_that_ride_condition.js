// This program check the eligible to ride
var hight = 42 // variable for riders hight
var age = 10 // variable for riders age 
// function to check the conditions meets to ride on the ride. 
if (hight >= 42 && age >= 10) {
    console.log( "Get on that ride, Kiddo")
}
else {
    console.log("Sory Kiddo. Maybe next year!")
}
