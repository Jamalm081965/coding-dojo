// Setting variable to like count
var likeCount = 0;
// this function will increase the like count
function increaseLikes() {
    // This operation loop thru the like count and increase it by
    likeCount = likeCount + 1;
}
