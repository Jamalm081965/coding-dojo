function greeting(){
	return "Hello world";
}
var word = greeting()
console.log(word);