class BankAccount:
    def __init__(self, int_rate, balance):
        self.int_rate = int_rate
        self.balance = balance

    def deposit(self, amount):

        self.balance += amount
        return self

    def deposit(self, amount):
        self.deposit + amount
        return self.balance

    def with_draw(self, amount):
        if self.balance > amount:
            self.balance - amount
            return self 
        else:
            print(f"You have Insufficient funds: {self.balance} Charging a $5 fee")
            self.balance - 5
            return self

    def display_account_info(self):
        print(f"Balance {self.balance}")

    def yield_interest(self):
        self.balance * self.int_rate
        return self

# Create an instance of BankAccount
account_jamal = BankAccount(0.01, 100)

# Call the display_balance method
account_jamal.display_account_info()

# Deposit money and display balance again
account_jamal.deposit(50)

# Withdraw money and display balance
account_jamal.with_draw(30)
account_jamal.yield_interest(0.01)


# Create an instance of BankAccount
account_lee = BankAccount(0.02, 300)

# Call the display_balance method
account_lee.display_account_info()

# Deposit money and display balance again
account_lee.deposit(200)

# Withdraw money and display balance
account_lee.with_draw(70)
# calculating the interest
account_lee.yield_interest(0.03)
